class MyClass{
public:
void foo();
int bar;
};
