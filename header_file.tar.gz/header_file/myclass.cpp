#include <iostream>
#include "myclass.h"
int main{
	int 
}
